var days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
var expenditure = [20,12, 15, 10, 30, 25, 40 ];

var $ = function(id) { return document.getElementById(id); };

window.onload = function() {
    //event handlers







};
